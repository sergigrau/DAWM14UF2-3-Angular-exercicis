"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Exercici que converteix un caràcter a binari, hex,etc
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que converteix un caràcter a binari, hex,etc
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
var core_1 = require("@angular/core");
/// Component principal
var Ex01_Component = (function () {
    function Ex01_Component() {
        this.decimal = 0;
        this.binari = '';
        this.hexadecimal = '';
        this.octal = '';
    }
    Ex01_Component.prototype.convertir = function (valor) {
        var nombre;
        if (valor != undefined)
            nombre = valor.charCodeAt(0);
        this.decimal = nombre;
        this.binari = (nombre >>> 0).toString(2);
        this.hexadecimal = (nombre >>> 0).toString(16);
        this.octal = (nombre >>> 0).toString(8);
    };
    return Ex01_Component;
}());
Ex01_Component = __decorate([
    core_1.Component({
        selector: 'aplicacio',
        styleUrls: ['/app/E01_activitats.css'],
        templateUrl: '/app/Ex01_conversio.html'
    })
], Ex01_Component);
exports.Ex01_Component = Ex01_Component;
;
//# sourceMappingURL=Ex01_conversio.component.js.map