/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
import {
  Component, Pipe, Directive,
  NgModule
} from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';

/// Component principal
@Component({
  styleUrls: ['/app/E01_activitats.css'],
  templateUrl: '/app/Ex03_detall.html'
})
export class Ex03_DetallComponent {  

private id:string;
private n:string='sergi';
private nota:string='11';
private sub: any;      // -> Subscriber

  constructor(private route: ActivatedRoute) {}
ngOnInit() {
   // get URL parameters
    this.sub = this.route
        .params
        .subscribe(params => {            
            this.id = params['id']; 
            this.n = params['n']; 
            this.nota = params['nota']; 
    });
    };
  }



