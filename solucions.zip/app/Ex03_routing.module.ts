import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Ex03_AppComponent } from './Ex03_app.component';
import { Ex03_LlistaComponent } from './Ex03_llista.component';
import { Ex03_DetallComponent } from './Ex03_detall.component';
import { Ex03_ErrorComponent } from './Ex03_error.component';

const rutes: Routes = [

  { path: 'detall/:id', component: Ex03_DetallComponent  },
  { path: 'llistat', component: Ex03_LlistaComponent },
  { path: '', component: Ex03_AppComponent },
  { path: '**', component: Ex03_ErrorComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(rutes)],
  exports: [RouterModule]
})
export class Ex03_Module { }