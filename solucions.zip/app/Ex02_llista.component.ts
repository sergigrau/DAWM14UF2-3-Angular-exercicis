/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
import {
  Component, Pipe, Directive,
  NgModule
} from '@angular/core';

/// interface que representa un Alumne (Model)
interface Alumne {
  n: string;
  nota: number;
}

/// Component principal
@Component({
  selector: 'aplicacio',
  styleUrls: ['/app/E01_activitats.css'],
  templateUrl: '/app/Ex02_llista.html'
})
export class Ex02_Component {
  alumnes: Alumne[];

  constructor() {
    this.inicialitzarAlumnes();
  };

  private inicialitzarAlumnes() {
    this.alumnes = [
      {
        n: 'Sergi',
        nota: 10
      }, {
        n: 'Joan',
        nota: 7
      },
      {
        n: 'Anna',
        nota: 5
      },
    ];
  }
  public ordenarPerNom() {
    this.alumnes.sort().reverse();
  }

  public filtrarPerNom(valor: string) {
    if (valor.length == 0) {
      this.inicialitzarAlumnes();
    }
    else {
      let v= Number(valor);
      this.alumnes = this.alumnes.filter(function(alumne){
        return alumne.nota>v;
      })
    }

  }
}


