/*
 * Exercici que converteix un caràcter a binari, hex,etc
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que converteix un caràcter a binari, hex,etc
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
import {
  Component, Pipe, Directive,
  NgModule
} from '@angular/core';

/// Component principal
@Component({
  selector: 'aplicacio',
  styleUrls: ['/app/E01_activitats.css'],
  templateUrl: '/app/Ex01_conversio.html'
})
export class Ex01_Component {
  decimal: number = 0;
  binari: string = '';
  hexadecimal: string = '';
  octal: string = '';
  convertir(valor: string) {

    let nombre: number;

    if (valor != undefined)
      nombre = valor.charCodeAt(0);

    this.decimal = nombre;
    this.binari = (nombre >>> 0).toString(2);
    this.hexadecimal = (nombre >>> 0).toString(16);
    this.octal = (nombre >>> 0).toString(8);

  }
};

