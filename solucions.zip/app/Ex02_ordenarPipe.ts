/*
 * pipe d'ordenació d'un nom. En realitat per l'exercici no és necessaria
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - * pipe d'ordenació d'un nom
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
import {
  Component, Pipe, PipeTransform, Directive,
  NgModule
} from '@angular/core';


@Pipe({
  name: "orderby"
})
export class OrdenarPipe implements PipeTransform {
  transform(array: Array<any>, args?) {

    if (array) {
      let orderByValue = args[0]
      let byVal = 1
      if (orderByValue.charAt(0) == "!") {
        byVal = -1
        orderByValue = orderByValue.substring(1)
      }
      console.log("byVal", byVal);
      console.log("orderByValue", orderByValue);

      array.sort((a: any, b: any) => {
        if (a[orderByValue] < b[orderByValue]) {
          return -1 * byVal;
        } else if (a[orderByValue] > b[orderByValue]) {
          return 1 * byVal;
        } else {
          return 0;
        }
      });
      return array;
    }
  }
}

