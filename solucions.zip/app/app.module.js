"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var Ex01_conversio_component_1 = require("./Ex01_conversio.component");
var Ex02_llista_component_1 = require("./Ex02_llista.component");
var Ex03_app_component_1 = require("./Ex03_app.component");
var Ex03_llista_component_1 = require("./Ex03_llista.component");
var Ex03_detall_component_1 = require("./Ex03_detall.component");
var Ex03_error_component_1 = require("./Ex03_error.component");
var Ex02_ordenarPipe_1 = require("./Ex02_ordenarPipe");
var Ex03_routing_module_1 = require("./Ex03_routing.module");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        //imports: [BrowserModule],
        imports: [platform_browser_1.BrowserModule, Ex03_routing_module_1.Ex03_Module],
        providers: [
            { provide: core_1.LOCALE_ID, useValue: "ca" },
        ],
        declarations: [
            Ex01_conversio_component_1.Ex01_Component,
            Ex02_llista_component_1.Ex02_Component,
            Ex03_app_component_1.Ex03_AppComponent,
            Ex03_llista_component_1.Ex03_LlistaComponent,
            Ex03_detall_component_1.Ex03_DetallComponent,
            Ex03_error_component_1.Ex03_ErrorComponent,
            Ex02_ordenarPipe_1.OrdenarPipe
        ],
        bootstrap: [Ex03_app_component_1.Ex03_AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map