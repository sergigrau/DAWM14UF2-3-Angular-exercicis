/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
import {
  Component
} from '@angular/core';
import { Router } from '@angular/router';

/// Component principal
@Component({
  selector: 'aplicacio',
  styleUrls: ['/app/E01_activitats.css'],
  template: ` <router-outlet></router-outlet>`
})
export class Ex03_AppComponent {
  }


