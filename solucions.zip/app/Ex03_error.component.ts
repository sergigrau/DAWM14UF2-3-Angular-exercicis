/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
import {
  Component, Pipe, Directive,
  NgModule
} from '@angular/core';

import { Router } from '@angular/router';

/// Component principal
@Component({
  template: `
  <h2>error </h2>
  `
})
export class Ex03_ErrorComponent {  

}


