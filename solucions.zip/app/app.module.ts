import { NgModule, LOCALE_ID } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Ex01_Component } from './Ex01_conversio.component';
import { Ex02_Component } from './Ex02_llista.component';
import { Ex03_AppComponent } from './Ex03_app.component';
import { Ex03_LlistaComponent } from './Ex03_llista.component';
import { Ex03_DetallComponent } from './Ex03_detall.component';
import { Ex03_ErrorComponent } from './Ex03_error.component';
import { OrdenarPipe } from './Ex02_ordenarPipe';
import { Ex03_Module } from './Ex03_routing.module';

@NgModule({
 //imports: [BrowserModule],
   imports: [BrowserModule, Ex03_Module],
  providers: [
    { provide: LOCALE_ID, useValue: "ca" },
  ],
  declarations: [
    Ex01_Component,
    Ex02_Component,
    Ex03_AppComponent, 
    Ex03_LlistaComponent, 
    Ex03_DetallComponent,
     Ex03_ErrorComponent,
    OrdenarPipe],
  bootstrap: [Ex03_AppComponent]
})
export class AppModule { }
