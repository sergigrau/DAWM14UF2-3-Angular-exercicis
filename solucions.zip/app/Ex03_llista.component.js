"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
/// Component principal
var Ex03_LlistaComponent = (function () {
    function Ex03_LlistaComponent(route, router) {
        this.route = route;
        this.router = router;
        this.inicialitzarAlumnes();
    }
    Ex03_LlistaComponent.prototype.inicialitzarAlumnes = function () {
        this.alumnes = [
            {
                n: 'Sergi',
                nota: 10
            }, {
                n: 'Joan',
                nota: 7
            },
            {
                n: 'Anna',
                nota: 5
            },
        ];
    };
    Ex03_LlistaComponent.prototype.anarDetall = function (id) {
        this.router.navigate(['/detall', id, this.alumnes[id]]);
    };
    return Ex03_LlistaComponent;
}());
Ex03_LlistaComponent = __decorate([
    core_1.Component({
        styleUrls: ['/app/E01_activitats.css'],
        templateUrl: '/app/Ex03_llista.html'
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute,
        router_1.Router])
], Ex03_LlistaComponent);
exports.Ex03_LlistaComponent = Ex03_LlistaComponent;
//# sourceMappingURL=Ex03_llista.component.js.map