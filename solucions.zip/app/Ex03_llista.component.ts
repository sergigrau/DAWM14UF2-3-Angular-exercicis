/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
import {
  Component, Pipe, Directive,
  NgModule
} from '@angular/core';

import { Router, ActivatedRoute, Params } from '@angular/router';

/// interface que representa un Alumne (Model)
interface Alumne {
  n: string;
  nota: number;
}

/// Component principal
@Component({
  styleUrls: ['/app/E01_activitats.css'],
  templateUrl: '/app/Ex03_llista.html'
})
export class Ex03_LlistaComponent {
  private alumnes: Alumne[];

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {
        this.inicialitzarAlumnes();
  }

  private inicialitzarAlumnes() {
    this.alumnes = [
      {
        n: 'Sergi',
        nota: 10
      }, {        
        n: 'Joan',
        nota: 7
      },
      {
        n: 'Anna',
        nota: 5
      },
    ];
  }
  public anarDetall(id) {
    this.router.navigate(['/detall', id, this.alumnes [id]]);
  }
}


