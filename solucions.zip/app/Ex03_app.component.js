"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
var core_1 = require("@angular/core");
/// Component principal
var Ex03_AppComponent = (function () {
    function Ex03_AppComponent() {
    }
    return Ex03_AppComponent;
}());
Ex03_AppComponent = __decorate([
    core_1.Component({
        selector: 'aplicacio',
        styleUrls: ['/app/E01_activitats.css'],
        template: " <router-outlet></router-outlet>"
    })
], Ex03_AppComponent);
exports.Ex03_AppComponent = Ex03_AppComponent;
//# sourceMappingURL=Ex03_app.component.js.map