"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
var core_1 = require("@angular/core");
/// Component principal
var Ex02_Component = (function () {
    function Ex02_Component() {
        this.inicialitzarAlumnes();
    }
    ;
    Ex02_Component.prototype.inicialitzarAlumnes = function () {
        this.alumnes = [
            {
                n: 'Sergi',
                nota: 10
            }, {
                n: 'Joan',
                nota: 7
            },
            {
                n: 'Anna',
                nota: 5
            },
        ];
    };
    Ex02_Component.prototype.ordenarPerNom = function () {
        this.alumnes.sort().reverse();
    };
    Ex02_Component.prototype.filtrarPerNom = function (valor) {
        if (valor.length == 0) {
            this.inicialitzarAlumnes();
        }
        else {
            var v_1 = Number(valor);
            this.alumnes = this.alumnes.filter(function (alumne) {
                return alumne.nota > v_1;
            });
        }
    };
    return Ex02_Component;
}());
Ex02_Component = __decorate([
    core_1.Component({
        selector: 'aplicacio',
        styleUrls: ['/app/E01_activitats.css'],
        templateUrl: '/app/Ex02_llista.html'
    }),
    __metadata("design:paramtypes", [])
], Ex02_Component);
exports.Ex02_Component = Ex02_Component;
//# sourceMappingURL=Ex02_llista.component.js.map