"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 * @author sergi grau, sergi.grau@fje.edu
 * @version 1.0
 * date 08.02.2017
 * format del document UTF-8
 *
 * CHANGELOG
 * 08.02.2017
 * - Exercici que mostra una llista ordenada d'alumnes i els pot filtrar i ordenar
 *
 * NOTES
 * ORIGEN
 * Desenvolupament Aplicacions Web. Jesuïtes El Clot
 */
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
/// Component principal
var Ex03_DetallComponent = (function () {
    function Ex03_DetallComponent(route) {
        this.route = route;
        this.n = 'sergi';
        this.nota = '11';
    }
    Ex03_DetallComponent.prototype.ngOnInit = function () {
        var _this = this;
        // get URL parameters
        this.sub = this.route
            .params
            .subscribe(function (params) {
            _this.id = params['id'];
            _this.n = params['n'];
            _this.nota = params['nota'];
        });
    };
    ;
    return Ex03_DetallComponent;
}());
Ex03_DetallComponent = __decorate([
    core_1.Component({
        styleUrls: ['/app/E01_activitats.css'],
        templateUrl: '/app/Ex03_detall.html'
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute])
], Ex03_DetallComponent);
exports.Ex03_DetallComponent = Ex03_DetallComponent;
//# sourceMappingURL=Ex03_detall.component.js.map