"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var Ex03_app_component_1 = require("./Ex03_app.component");
var Ex03_llista_component_1 = require("./Ex03_llista.component");
var Ex03_detall_component_1 = require("./Ex03_detall.component");
var Ex03_error_component_1 = require("./Ex03_error.component");
var rutes = [
    { path: 'detall/:id', component: Ex03_detall_component_1.Ex03_DetallComponent },
    { path: 'llistat', component: Ex03_llista_component_1.Ex03_LlistaComponent },
    { path: '', component: Ex03_app_component_1.Ex03_AppComponent },
    { path: '**', component: Ex03_error_component_1.Ex03_ErrorComponent },
];
var Ex03_Module = (function () {
    function Ex03_Module() {
    }
    return Ex03_Module;
}());
Ex03_Module = __decorate([
    core_1.NgModule({
        imports: [router_1.RouterModule.forRoot(rutes)],
        exports: [router_1.RouterModule]
    })
], Ex03_Module);
exports.Ex03_Module = Ex03_Module;
//# sourceMappingURL=Ex03_routing.module.js.map